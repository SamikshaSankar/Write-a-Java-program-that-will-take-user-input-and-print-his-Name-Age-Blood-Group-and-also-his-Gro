package com.company;
import java.util.*;
public class Main {
    public static void main(String[] args) {

        String name;
        int age;
        String bloodGroup;

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter your Name: ");
        name = scanner.nextLine();

        System.out.println("Enter your Age: ");
        age = scanner.nextInt();

        System.out.println("Enter your Blood Group: ");
        bloodGroup = scanner.next();

        System.out.println("--------------------------");
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Blood Group: " + bloodGroup);
        System.out.println("--------------------------");

         String group;
         if( age >=20 ){
             group = ("Your group is RED");
        }else if(age >=15){
             group = ("Your group is BLUE");
         }else if(age >= 10){
             group = ("Your group is YELLOW");
         }else{
             group = ("You can't belong any group");
         }
          System.out.println(group);



    }
}